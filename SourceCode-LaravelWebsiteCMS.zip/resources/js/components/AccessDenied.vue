<template>
<div id="notfound">
     <div class="notfound">
          <div class="notfound-403">
          <h1>A<span>cc</span>ess D<span>e</span>ni<span>e</span>d</h1>
          </div>
          <p>You Don't Have Permission To Access This Module</p>
          <router-link to="/admin/dashboard">home page</router-link>

     </div>
</div>
</template>
