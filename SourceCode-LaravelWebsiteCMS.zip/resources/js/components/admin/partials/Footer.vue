<template>
<div class="footer bg-white py-4 d-flex flex-lg-column" id="tc_footer">
					
    <div
        class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted font-weight-bold mr-2">2020©</span>
            <a href="#" target="_blank" class="text-dark-75 text-hover-primary">Themescoder</a>
        </div>

        <div class="nav nav-dark">
            <a href="#" target="_blank" class="nav-link pl-0 pr-5">About</a>
            <a href="#c" target="_blank" class="nav-link pl-0 pr-5">Team</a>
            <a href="#" target="_blank" class="nav-link pl-0 pr-0">Contact</a>
        </div>

    </div>

</div>
<!--end::Footer-->
</template>