<template id="blog-template">
<div class="col-12 col-sm-12 col-md-6">
    <div class="blog">
        <div class="blog-thumbnail">
            <span class="date-tag badge blog-template-date"></span>
            <a href="" class="blog-template-image-link">
                <img class="img-thumbnail blog-template-image" src="" width="100%">
            </a>
        </div>
        <div class="blog-detial">
            <span class="tag blog-template-category">
            </span>
            <h5><a class="blog-template-title" href=""></a></h5>

            <p class="blog-template-description">
            </p>
            <span class="blink"><a class="blog-template-readmore-link" href="">Read More.. </a></span>
        </div>

    </div>
</div>
</template>