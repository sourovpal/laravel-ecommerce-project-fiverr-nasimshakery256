<div class="alert alert-warning alert-dismissible alert-cookie fade show" role="alert">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-md-8 col-lg-9">
                <div class="pro-description">
                    This site uses cookies. By continuing to browse the site you are agreeing to our use of cookies. Review our <a href="javascript:void(0)" class="btn-link">cookies information</a> for more details.
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-3">
                <button type="button" class="btn btn-secondary swipe-to-top" data-dismiss="alert" aria-label="Close">
                      OK, I agree
                    </button>
            </div>
        </div>
    </div>
  </div>