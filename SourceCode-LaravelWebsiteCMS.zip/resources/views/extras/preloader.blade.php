
<!-- Paste this code after body tag -->
<div class="se-pre-con">
    <div class="pre-loader">
      <div class="la-line-scale">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
      <p>Loading..</p>
    </div>
 
  </div>