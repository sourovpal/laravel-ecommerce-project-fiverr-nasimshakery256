<div class="dropdown switecher-new" style="display: none;">
    <button class="btn btn-primary swipe-to-top dropdown-toggle" type="button" id="headerOneCartButton"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" > 
      <i class="fa fa-cogs" aria-hidden="true"></i>
    </button> 
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="headerOneCartButton">
      
      <a href="javascript:void(0)" class="swticher-rtl">
        <div class="text ">Use demo with RTL</div>
        <div class="toggle">
          <span class="circle "></span>
        </div>
      
    </a>
    <a href="javascript:void(0)" class="swticher-boxed ">
        <div class="text ">Use demo with Box</div>
        <div class="toggle">
          <span class="circle"></span>
        </div>
    </a>

    <div class="swicher-color">
        <div class="text "><b>Use demo with Colors</b></div>
        <ul id="switchColor" > 
          <li class="active">
            <a href="javascript:void(0)" id="default"><div id="sprite1" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="brown"><div id="sprite2" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="red"><div id="sprite3" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="green"><div id="sprite4" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="purple"><div id="sprite5" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="dark-brown"><div id="sprite6" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="light-yellow"><div id="sprite7" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="light-blue"><div id="sprite8" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="pink"><div id="sprite9" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="orange"><div id="sprite10" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="light-gray"><div id="sprite11" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="light-purple"><div id="sprite12" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="light-pink"><div id="sprite13" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="gray"><div id="sprite14" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="light-green"><div id="sprite15" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="zinc"><div id="sprite16" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="dark-green"><div id="sprite17" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="light-zinc"><div id="sprite18" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="light-maroon"><div id="sprite19" ></div></a>
          </li>
          <li>
            <a href="javascript:void(0)" id="black"><div id="sprite20" ></div></a>
          </li>
        </ul>
       </div>
      
    </div>
  </div>