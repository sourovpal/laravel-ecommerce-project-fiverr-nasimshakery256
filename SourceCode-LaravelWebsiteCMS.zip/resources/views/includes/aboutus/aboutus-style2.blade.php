
      <div class="container-fuild">
        <nav aria-label="breadcrumb">
            <div class="container">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="./">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Aboutus</li>
                </ol>
            </div>
          </nav>
      </div> 
      
      <section class="pro-content">
        <div class="container">
          <div class="page-heading-title">
            <h2> ABOUTS 
            </h2>
          </div>
      </div>
      <!-- About-us Content -->
      <section class="aboutus-content">
        
        <div class="container iframe-container">
          
          <div class="row">
              <div class="col-12 col-md-6">
                  <video width="320" height="240" controls="">
                      <source src="*.mp4" type="video/mp4">
                      <source src="*.ogg" type="video/ogg">
                      Your browser does not support the video tag.
                    </video>
              </div>
              <div class="col-12 col-md-6">
                    <p class="peragraph2">
                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf
                        moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                        Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda
                        shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                        proident. Ad vegan excepteur butcher vice lomo.
                    </p>
                    <p class="peragraph2">
                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf
                        moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                        Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda
                        shoreditch et.
                    </p>

              </div>
          </div>
        </div>

        <div class="container accordion-main pro-content">
          <div class="row">
              <div class="col-12 col-md-6">
                  <div class="heading">
                      <h5>
                        OUR VISION
                      </h5>
                    </div>
                  <section class="accordion-card">

                      <!--Accordion wrapper-->
                      <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
              
                        <!-- Accordion card -->
                        <div class="card">
              
                          <!-- Card header -->
                          <div class="card-header" role="tab" id="headingOne1">
                            <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1" aria-expanded="true" aria-controls="collapseOne1" class="">
                              <h5>
                                WHO WE ARE<i class="fas fa-angle-down"></i>
                              </h5>
                            </a>
                          </div>
              
                          <!-- Card body -->
                          <div id="collapseOne1" class="collapse show" role="tabpanel" aria-labelledby="headingOne1" data-parent="#accordionEx" style="">
                            <div class="card-body">
                              Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf
                              moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                              Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda
                              shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                              proident. Ad vegan excepteur butcher vice lomo.
                            </div>
                          </div>
              
                        </div>
                        <!-- Accordion card -->
              
                        <!-- Accordion card -->
                        <div class="card">
              
                          <!-- Card header -->
                          <div class="card-header" role="tab" id="headingTwo2">
                            <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo2">
                              <h5>
                                WHAT WE WANT<i class="fas fa-angle-down"></i>
                              </h5>
                            </a>
                          </div>
              
                          <!-- Card body -->
                          <div id="collapseTwo2" class="collapse" role="tabpanel" aria-labelledby="headingTwo2" data-parent="#accordionEx">
                            <div class="card-body">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 
                                3 wolf moon officia aute, non cupidatat skateboard dolor brunch. 
                                Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, 
                                sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. 
                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. 
                                Ad vegan excepteur butcher vice lomo.
                            </div>
                          </div>
              
                        </div>
                        <!-- Accordion card -->
              
                        <!-- Accordion card -->
                        <div class="card">
              
                          <!-- Card header -->
                          <div class="card-header" role="tab" id="headingThree3">
                            <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseThree3" aria-expanded="false" aria-controls="collapseThree3">
                              <h5>
                                WHAT WE CAN GIVE<i class="fas fa-angle-down"></i>
                              </h5>
                            </a>
                          </div>
              
                          <!-- Card body -->
                          <div id="collapseThree3" class="collapse" role="tabpanel" aria-labelledby="headingThree3" data-parent="#accordionEx">
                            <div class="card-body">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
                                  3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                                  Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.
                                    Nihil anim keffiyeh helvetica,
                                  craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.
                            </div>
                          </div>
              
                        </div>
                        <!-- Accordion card -->
              
                      </div>
                      <!-- Accordion wrapper -->
              
                  </section>
              </div>
              <div class="col-12 col-md-6">
                  <div class="heading">
                      <h5>
                        OUR OFFER
                      </h5>
                    </div>
                    <p class="peragraph2">
                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf
                        moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                        Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda
                        shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                        proident. Ad vegan excepteur butcher vice lomo.
                    </p>
                    <p class="peragraph2">
                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf
                        moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                        Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda
                        shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                        proident. Ad vegan excepteur butcher vice lomo.Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                        proident. Ad vegan excepteur butcher vice lomo.
                    </p>

              </div>
          </div>
            
        </div>
      
        <div class="conatiner-fluid profile-team pro-content">
            <div class="container">
                <div class="products-area">
                    <div class="row justify-content-center">
                        <div class="col-12 col-lg-6">
                          <div class="pro-heading-title">
                            <h2>Our Team
                            </h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                              Morbi venenatis felis tempus feugiat maximus. Aliquam erat volutpat. 
                              Aenean eget viverra mi. Duis pulvinar elit massa, vitae posuere urna blandit sed. 
                              Praesent ut dignissim risus. </p>
                          </div>
                        </div>
                      </div>
                    <div class="row">
                        <div class="col-lg-4 insta-discription">
                            <!--=======  instagram intro  =======-->
                            
                            <div class="instagram-section-intro">
                                <p><a href="javascript:void(0)">@ecommerce_shop</a></p>
                                <h3>Follow us on Instagram</h3>
                            </div>
                            
                            <!--=======  End of instagram intro  =======-->
                        </div>
                        <div class="col-lg-8">
                          <div class="insta-js row">
                              <div class="col-12 col-md-12 col-lg-6">
                                  <picture>
                                    <a href="https://www.instagram.com/p/B4juODoFKIU/" target="_blank">
                                      <img class="img-fluid" src="{{ asset('assets/front/images/instagram/insta_1.jpg') }}" alt="Instagram">
                                    </a>
                                  </picture>
                              </div>
                              <div class="col-12 col-md-12 col-lg-6">
                                  <picture>
                                      <a href="https://www.instagram.com/p/B4juNO3ldrZ/" target="_blank">
                                        <img class="img-fluid" src="{{ asset('assets/front/images/instagram/insta_2.jpg') }}" alt="Instagram">
                                      </a>
                                    </picture>
                              </div>
                              <div class="col-12 col-md-12 col-lg-6">
                                  <picture>
                                      <a href="https://www.instagram.com/p/B4juMiFFPEr/" target="_blank">
                                        <img class="img-fluid" src="{{ asset('assets/front/images/instagram/insta_3.jpg') }}" alt="Instagram">
                                      </a>
                                    </picture>
                              </div>
                              <div class="col-12 col-md-12 col-lg-6">
                                  <picture>
                                      <a href="https://www.instagram.com/p/B4juLuwFUim/" target="_blank">
                                        <img class="img-fluid" src="{{ asset('assets/front/images/instagram/insta_4.jpg') }}" alt="Instagram">
                                      </a>
                                    </picture>
                              </div>
                              <div class="col-12 col-md-12 col-lg-6">
                                  <picture>
                                      <a href="https://www.instagram.com/p/B4juODoFKIU/" target="_blank">
                                        <img class="img-fluid" src="{{ asset('assets/front/images/instagram/insta_1.jpg') }}" alt="Instagram">
                                      </a>
                                       
                                    </picture>
                                
                              </div>
                              <div class="col-12 col-md-12 col-lg-6">
                                  <picture>
                                      <a href="https://www.instagram.com/p/B4juNO3ldrZ/" target="_blank">
                                        <img class="img-fluid" src="{{ asset('assets/front/images/instagram/insta_2.jpg') }}" alt="Instagram">
                                      </a>
                                    </picture>
                                  
                              </div>
                              <div class="col-12 col-md-12 col-lg-6">
                                  <picture>
                                      <a href="https://www.instagram.com/p/B4juMiFFPEr/" target="_blank">
                                        <img class="img-fluid" src="{{ asset('assets/front/images/instagram/insta_3.jpg') }}" alt="Instagram">
                                      </a>
                                    </picture>
                             
                              </div>
                              <div class="col-12 col-md-12 col-lg-6">
                                  <picture>
                                      <a href="https://www.instagram.com/p/B4juLuwFUim/" target="_blank">
                                        <img class="img-fluid" src="{{ asset('assets/front/images/instagram/insta_4.jpg') }}" alt="Instagram">
                                      </a>
                                    </picture>
                              </div>

                          </div>
                        </div>
                    </div>
                    </div> 
            </div>
        </div>
      </section>
      </section>
