
    <div class="container-fuild">
      <nav aria-label="breadcrumb">
          <div class="container">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="./">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Aboutus</li>
              </ol>
          </div>
        </nav>
    </div> 
    
    <section class="pro-content">
      <div class="container">
        <div class="page-heading-title">
            <h2> ABOUTS 
            </h2>
         
            </div>
    </div>
    <!-- About-us Content -->
    <section class="aboutus-content">
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-6 img-portion">
              <img class="img-fluid" src="{{ asset('assets/front/images/about-us/full-width.jpg') }}">
          </div>
          <div class="col-12 col-md-6">
              <div class="peragraph">
                  <p>
                     Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                     sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                     Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                     sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  </p>
                  <div class="pre-info">
                      <h5 class="widget-title">ADDRESS</h5>
                      <p class="widget-content">1800 Abbot Kinney Blvd. Unit D &amp; E Venice</p>
                  </div>
                <div class="pre-info">
                    <h5 class="widget-title">PHONE</h5>
                    <p class="widget-content">Mobile: +88 – 1990</p>
                    <p class="widget-content">Hotline: 1800 – 1102</p>
                </div>
                <div class="pre-info">
                    <h5 class="widget-title">EMAIL</h5>
                      <p class="widget-content">Support@ecommerce.com</p>
                </div>
                </div>
            </div>
        </div>
       
     
  
      </div>  
      <div class="container-fluid profile-div">
          <div class="container">
              <div class="media-main">
                  <div class="row">
                     <div class="col-12 col-md-6 media-col">
                         <div class="media">
                             <img src="{{ asset('assets/front/images/about-us/profile.png') }}" alt="profile" class="rounded-circle" style="width:100px;">
                             <div class="media-body">
                               <h4>John Doe <small>Sales Executive</small></h4>
                               <p>  Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                                   sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                   Lorem ipsum dolor sit amet, consectetur adipiscing elit, </p>
                             </div>
                           </div>
                      </div>
                      <div class="col-12 col-md-6">
                         <div class="media">
                             <img src="{{ asset('assets/front/images/about-us/profile.png') }}" alt="profile" class="rounded-circle" style="width:100px;">
                             <div class="media-body">
                               <h4>John Doe  <small>Sales Executive</small></h4>
                               <p>  Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                                   sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                   Lorem ipsum dolor sit amet, consectetur adipiscing elit, </p>
                             </div>
                           </div>
                      </div>
                  </div>
                  
              </div>
          </div>
      </div>
      <div class="conatiner-fluid profile-team pro-content">
        <div class="container">
          <div class="row justify-content-center">
              <div class="col-12 col-lg-6">
                <div class="pro-heading-title">
                    <h2> Our Team
                    </h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                      Morbi venenatis felis tempus feugiat maximus. Aliquam erat volutpat. 
                    </p>
                </div>
              </div>
          </div>
        </div>
          <div class="container">
              <div class="products-area">
                
                  <div class="row">
                    <div class="col-12">
                        <div class="aboutus-carousel-js row">
                            <div class="col-12 col-md-12 col-lg-6">
                                <div class="product">
                                  <article>
                                    <img src="{{ asset('assets/front/images/about-us/14_01_about us2.jpg') }}" class="img-fluid" alt="blogImage">
                                  
                                      <div class="aboutdetail">
                                        <div class="pro-title">
                                          <h5>Senior Frontend Developer</h5>
                                          </div>
                                          <div class="pro-entry-content">
                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                            </div>
                                      
                                      </div>
                                          <div class="over"></div>
                                  </article>
                                </div>
                            </div>
                            <div class="col-12 col-md-12 col-lg-6">
                                <div class="product">
                                  <article>
                                    <img src="{{ asset('assets/front/images/about-us/14_01_about us2.jpg') }}" class="img-fluid" alt="blogImage">
                                    <div class="aboutdetail">
                                      <div class="pro-title">
                                        <h5>Senior Frontend Developer</h5>
                                        </div>
                                        <div class="pro-entry-content">
                                          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                          </div>
                                    
                                    </div>
                                  
                                          <div class="over"></div>
                                  </article>
                                </div>
                            </div>
                            <div class="col-12 col-md-12 col-lg-6">
                                <div class="product">
                                  <article>
                                    <img src="{{ asset('assets/front/images/about-us/14_01_about us2.jpg') }}" class="img-fluid" alt="blogImage">
                                  
                                    <div class="aboutdetail">
                                      <div class="pro-title">
                                        <h5>Senior Frontend Developer</h5>
                                        </div>
                                        <div class="pro-entry-content">
                                          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                          </div>
                                    
                                    </div>
                                  
                                          <div class="over"></div>
                                  </article>
                                </div>
                            </div>
                            <div class="col-12 col-md-12 col-lg-6">
                                <div class="product">
                                  <article>
                                    <img src="{{ asset('assets/front/images/about-us/14_01_about us2.jpg') }}" class="img-fluid" alt="blogImage">
                                  
                                    <div class="aboutdetail">
                                      <div class="pro-title">
                                        <h5>Senior Frontend Developer</h5>
                                        </div>
                                        <div class="pro-entry-content">
                                          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                          </div>
                                    
                                    </div>
                                  
                                          <div class="over"></div>
                                  </article>
                                </div>
                            </div>
                            <div class="col-12 col-md-12 col-lg-6">
                                <div class="product">
                                  <article>
                                    <img src="{{ asset('assets/front/images/about-us/14_01_about us2.jpg') }}" class="img-fluid" alt="blogImage">
                                  
                                    <div class="aboutdetail">
                                      <div class="pro-title">
                                        <h5>Senior Frontend Developer</h5>
                                        </div>
                                        <div class="pro-entry-content">
                                          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                          </div>
                                    
                                    </div>
                                  
                                          <div class="over"></div>
                                  </article>
                                </div>
                            </div>
                            <div class="col-12 col-md-12 col-lg-6">
                                <div class="product">
                                  <article>
                                    <img src="{{ asset('assets/front/images/about-us/14_01_about us2.jpg') }}" class="img-fluid" alt="blogImage">
                                  
                                    <div class="aboutdetail">
                                      <div class="pro-title">
                                        <h5>Senior Frontend Developer</h5>
                                        </div>
                                        <div class="pro-entry-content">
                                          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                          </div>
                                    
                                    </div>
                                  
                                          <div class="over"></div>
                                  </article>
                                </div>
                            </div>
                          
                        </div>  
                    </div>
                  </div>
                 </div> 
          </div>
      </div>
    </section>
    </section>
