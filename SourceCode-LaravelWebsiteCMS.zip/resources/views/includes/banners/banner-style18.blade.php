<div class="banner-eighteen banner_div  banners-content">

  <div class="container">
    <div class="group-banners">
        <div class="row">
          <div class="col-12 col-md-5">
            <div class="imagespace">
            <figure class="banner-image ">
              <a href="" class="banner-link1"><img class="img-fluid banner-image1" src="" alt="Banner Image"></a>
            </figure>
            </div>
          </div> 
          <div class="col-12 col-md-3">
            <div class="imagespace">
            <figure class="banner-image ">
              <a href="" class="banner-link2"><img class="img-fluid banner-image2" src="" alt="Banner Image"></a>
            </figure>
            </div>
          </div>
          <div class="col-12 col-md-4">
            <div class="imagespace">
            <figure class="banner-image ">
              <a href="" class="banner-link3"><img class="img-fluid banner-image3" src="" alt="Banner Image"></a>
            </figure>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12 col-md-5">
            <div class="imagespace">
            <figure class="banner-image ">
              <a href="" class="banner-link4"><img class="img-fluid banner-image4" src="" alt="Banner Image"></a>
            </figure>
            </div>
          </div> 
          <div class="col-12 col-md-3">
            <div class="imagespace">
            <figure class="banner-image ">
              <a href="" class="banner-link5"><img class="img-fluid banner-image5" src="" alt="Banner Image"></a>
            </figure>
            </div>
          </div>
          <div class="col-12 col-md-4">
            <div class="imagespace">
            <figure class="banner-image ">
              <a href="" class="banner-link6"><img class="img-fluid banner-image6" src="" alt="Banner Image"></a>
            </figure>
            </div>
          </div>
        </div>                          
    </div>
</div>
</div> 