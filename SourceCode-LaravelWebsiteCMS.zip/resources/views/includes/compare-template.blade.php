<template id="product-card-template">
    <div class="col-lg-6">
        <table class="table">
            <thead>
              <td align="center">
                <div class="img-div">
                    <img class="img-fluid product-card-image" src="images/compare/compare-1.png">
                </div>
               
              </td>
            </thead>
            <tbody>
              <tr>
                <td>
                  <h2  class="product-card-name"></h2>
                </td>
                
              </tr>      
              <tr>
                <td><span>Price&nbsp;:&nbsp;</span><span class="price-tag product-card-price"></span></td>
                
              </tr>
               <tr >
                    <td class="attribute">
                      
                    </td>
              </tr>
              
              <tr>
                <td>
                  <div class="detail-buttons">
                      <a href="#" class="btn btn-secondary swipe-to-top product-card-link">View Details</a>
                      <a href="#" class="btn  swipe-to-top remove-compare">Remove Compare</a>

                  </div>
                 
                </td>
                
              </tr>
            </tbody>
          </table>
    </div>
    </template>
    