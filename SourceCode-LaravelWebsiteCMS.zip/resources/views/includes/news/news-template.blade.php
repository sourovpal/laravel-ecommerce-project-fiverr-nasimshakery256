<template id="news-blog-template">
<div class="">
    <div class="blog">
        <div class="blog-thumbnail">
            <span class="date-tag badge news-blog-date">20-Mar-2019</span>
            <a href="blog-page1.html" class="news-blog-image-url">
                <img class="img-thumbnail news-blog-image" src="{{ asset('assets/front/images/product_images/product_image_22.png')}}" width="100%">
            </a>
            <div class="over"></div>
        </div>
        <div class="blog-detial">
            <span class="tag news-blog-category">
            </span>
            <h5><a href="" class="news-blog-name blog-url" ></a></h5>

            <p class="news-blog-desc" >
            </p>
            <span class="blink"><a class="read-more-url" href="">Read More.. </a></span>
        </div>

    </div>
</div>
</template>