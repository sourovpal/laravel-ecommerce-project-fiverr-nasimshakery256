<section class="product-content pro-content related-product">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-6">
                <div class="pro-heading-title">
                  <h2> {{ trans('lables.product-detail-related-product-title') }}
                  </h2>
                  <p>{{ trans('lables.product-detail-related-product-description') }}
                  </div>
            </div>

          </div>
    </div>
    <div class="general-product">
      <div class="container p-0 related">
      </div>
    </div>
</section>