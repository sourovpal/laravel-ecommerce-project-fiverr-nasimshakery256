 <!-- Product Modal -->
 @include('modals.quick-view-template')
 <div class="modal fade" id="quickViewModal" tabindex="-1" role="dialog" aria-hidden="true">

   <div class="modal-dialog modal-lg" role="document">
     <div class="modal-content">
       <div class="modal-body">

         <div class="container quick-view-modal-show">
         </div>
         <button type="button" class="close-quick-view-model" class="close" data-dismiss="modal" aria-label="Close" style="margin-top: 1px;margin-right: 2px;position: absolute;top: 0;right: 0;">
           <span aria-hidden="true">&times;</span>
         </button>
       </div>
     </div>
   </div>
 </div>
