@extends('layouts.master')
@section('content')

privacy policy

@endsection
@section('script')
@endsection
