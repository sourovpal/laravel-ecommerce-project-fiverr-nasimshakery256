
@include(isset(getSetting()['banner_style']) ? 'includes.banners.banner-'.getSetting()['banner_style'] : 'includes.banners.banner-style1')

