@extends('layouts.master')
@section('content')
terms
@endsection
@section('script')
@endsection
